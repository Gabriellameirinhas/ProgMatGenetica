Logo depois de executar o c�digo, voce deve digitar o nome do arquivo de entrada que possui uma matriz de restricao.
Os txts na pasta s�o diferentes entradas com 10 restri��es e 80 variaveis e a fun��o a maximizar na primeira linha.
