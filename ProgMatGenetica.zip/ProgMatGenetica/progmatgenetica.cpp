//Fernando de Oliveira Filho - 9266643
//Gabriel Lima Lameirinhas - 9266390
//Luiz Henrique Bento - 9266712


#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <cstdlib>

#define M    10 // n�mero de restri��es (linhas)
#define N    80 // n�mero de vari�veis (colunas)
#define P    100 // numero de individuos da popula��o inicial
#define F    50 // n�mero de filhos da popula��o inicial
#define Y    10 //n�mero total de todas as gera��es
#define H    1000 // numero total de gera��es

//pop[P+1][N+1] = matriz com todas as pessoas (populacao), e o fitness de cada um.
// 


int main(){

    int m[M+1][N+1], vetor[N+1], pop[P+1][N+1], matrizdefilhos[F+1][N+1],matrizdefilhos2[F+1][N+1], matrizfinal[P+F+1][N+1], G[H+1][N+1];
    int i, j, n, k, T, somarest, viavel, fitness, w, vp, x, soma, h, g=0, linha, max,l;
    char filename[256];

// Obtencao dos dados a partir do txt

    // Na matriz m, o elemento m[0][0] n�o � usado
    // A primeira linha traz os coeficientes da fun��o objetivo (m[0][1] a m[0][N])
    // A primeira coluna traz os RHS (m[1][0] a m[M][0])
    // O resto da matriz traz os coeficientes das restri��es
    // Todos os elementos da matriz s�o positivos

    printf("Digite o nome do arquivo que contem os coeficientes do problema: ");
    scanf("%s", filename);

    FILE *file = fopen(filename, "r");

    clock_t inicio = clock(); // inicia a contagem do tempo de execu��o do algoritmo

    for(i=0; i<=M; i++){ // faz a leitura dos coeficientes no arquivo texto e os coloca na matriz m
        for(j=0; j<=N; j++){
            fscanf(file, "%d", &m[i][j]);
        	
        }
    }
    printf("oi\n");
    
	fclose(file);
	
//Construindo Vetor Bin�rio 

	linha=0;
	for (k = 1; k <=P;k++){
		for(j=1;j<=N;j++){
			n = (rand()%2); // gerando aleatoriamente o vetor binario
	        vetor[j] = n;
		}

	
	//Vetor bin�rio X Matriz
		int somarest;
		int fitness = 0;
		int viavel = 1;
		
		for (i=1; i<=M; i++){
			somarest = 0;
			for (j=1; j<=N; j++){
				somarest += (m[i][j]*vetor[j]);  // Vetor bin�rio X vari�veis
				if (somarest > m[i][0]){					 // Testando se restri��o > vari�veis
					viavel = 0;
					break;		
				}			
			}
		}
		if (viavel == 1){
			for(j=1; j<=N; j++){
				pop[k][j] = vetor[j];
				fitness +=  vetor[j] * m[0][j];
			}
			pop[k][0] = fitness;
		}
		else
			k--;
				//jogar valores dentro da matriz de populacao
	}
		
	// aqui ja temos a primeira populacao criada
	// pop foi criado com uma linha a mais para utilizar de auxiliar na ordenacao
	// ordenando a matriz pop
	for (k=1; k<=P; k++){
        for (j=0; j<=80; j++)
            pop[0][j] = pop[k][j];   
		max=0;
										//Jogando a linha analisada na linha 0
	    for (i=k; i<P+1; i++){
	        if (max < pop[i][0]){
                max = pop[i][0];
                l = i;                       // Identificando qual linha cont�m o maior valor
	        }
	    }
	    for (j=0; j<=N; j++){
	        pop[k][j] = pop[l][j]; // sempre a linha sobreescrita ta salva na linha 0 da matriz pop
	        pop[l][j] = pop[0][j]; 
	    }
    }

// Ate aqui a matriz pop ja esta criada e ordenada

	//Crossing over & Mutacao
	for (h=1; h<=H; h++){ //serao feitas H geracoes			
		for (i=1;i<=F;i++){ //serao feitos F filhos de cada geracao
			T = 1 + rand()% (P/2);
			for (j=1;j<M/2;j++){				
				matrizdefilhos[i][j]= pop[T][j];
			}	
			
			T = 1 + rand() % (P/2);
			for (j=M/2;j<=M;j++){
				matrizdefilhos[i][j]= pop[T][j];
			}
			
			// checar viabilidade do filho
			// calcular o fitness
			viavel=1;
			for (w=1; w<=M; w++){
				somarest = 0;
				for (j=1; j<=N; j++){
					somarest += (m[w][j]*matrizdefilhos[i][j]);  // matriz de filhos X vari�veis
					if (somarest > m[w][0]){						 // Testando se restri��o > vari�veis
						viavel = 0;
						break;		
					}			
				}
			}
			if(viavel ==1){
				fitness=0;
				for(j=1; j<=N; j++){
					matrizdefilhos2[i][j] = matrizdefilhos[i][j];
					fitness += (matrizdefilhos[i][j] * m[0][j]);
				}
				matrizdefilhos2[i][0] = fitness;
			}else
				i--;
		}

		// ate aqui temos F filhos salvos em matrizdefilhos2


		// colocando a pop antiga em uma matrizfinal
		for (i=1;i<=P;i++){
			for (j=0;j<=N;j++){
				matrizfinal[i][j]= pop[i][j];
			}
		}

		//colocando os filhos na matrizfinal
		for (i=P+1;i<=P+F;i++) {
			for (j=0;j<=N;j++){
				matrizfinal[i][j]= matrizdefilhos2[i-P][j];
			}
		}

		// ordenando a matrizfinal
		for (k=1; k<=P+F; k++){
	        for (j=0; j<=80; j++)
	            matrizfinal[0][j] = matrizfinal[k][j];   
	            
			max=0;
											            //Jogando a linha analisada na linha 0
	        for (i=k; i<=P+F; i++){
	            if (max < matrizfinal[i][0]){
	                    max = matrizfinal[i][0];
	                    l = i;                       // Identificando qual linha cont�m o maior valor
	            }
	        }
	        for (j=0; j<=N; j++){
	            matrizfinal[k][j] = matrizfinal[l][j];
	            matrizfinal[l][j] = matrizfinal[0][j];
	        }
        }
        	
		
		//Muta��o e feita na populacao de filhos
			 
	    for(k=1;k<=P+F;k++){
	    	vp = 1 + rand() % N; // Aqui sao geradas as posicoes onde ocorrerao as mutacoes
	    	if (matrizfinal[k][vp]==0){
	    		matrizfinal[k][vp]=1;
	    	}		

	        soma = 0;
	        for (x=1;x<=M;x++){
				soma=0;
			    for (j=1;j<=N;j++){
	        		soma = soma + m[x][j]*matrizfinal[k][j];
	        	}
	    		if (soma > m[x][0]){
					matrizfinal[k][vp] = 1 - matrizfinal[k][vp]; // arrumando a matriz caso a mutacao nao seja viavel
					k--;
					break;  
				}    
	    	}
	    	fitness=0;

	    	for(j=1; j<=N; j++){
				fitness += matrizfinal[k][j] * m[0][j];
			}
			matrizfinal[k][0] = fitness; //atualiza fitness das mutacoes
		}
	    
		// ordenando p�s muta��o
			
		for (k=1; k<=P+F; k++){
	        for (j=0; j<=80; j++) //Jogando a linha analisada na linha 0
	            matrizfinal[0][j] = matrizfinal[k][j];   
	            
			max=0;
		
	        for (i=k; i<=P+F; i++){
	            if (max < matrizfinal[i][0]){
	                    max = matrizfinal[i][0];
	                    l = i;                       // Identificando qual linha cont�m o maior valor
	            }
	        }
	        for (j=0; j<=N; j++){
	            matrizfinal[k][j] = matrizfinal[l][j];
	            matrizfinal[l][j] = matrizfinal[0][j];
	        }
       
        } // final do programa
	        
	        
        for (i=1;i<=P;i++){
        	for(j=0;j<=N;j++){
        		pop[i][j]=matrizfinal[i][j]; //jogando a matriz final na pop com os P melhores individuos para retornar ao come�o do programa
        	}
        }
		for (j=0;j<=N;j++){
			G[h][j]= matrizfinal[1][j]; // matriz de geracoes
		}	
	}

	printf(" \n ");
	printf(" \n ");
	        
	for(i=1;i<=H;i++){
		printf("Melhor fitness da geracao %d: %d ", i, G[i][0]);
		printf(" \n ");
	}
							
// ESCRITA DO MELHOR INDIVIDUO NO ARQUIVO resposta.txt

    FILE *resposta = fopen("resposta.txt", "w");

    for(j=1; j<=N; j++){
        fprintf(resposta, "%d ", matrizfinal[1][j]); // aqui est� sendo colocado 0 para todas as posi��es, mas o algoritmo pronto dever� colocar a sequencia de bits (0 ou 1) do melhor individuo encontrado
    }
    fprintf(resposta, "\n");


// MEDI��O DO TEMPO DE EXECU��O DO ALGORITMO

    clock_t fim = clock();
    float tempo = (float)(fim - inicio) / CLOCKS_PER_SEC;

    printf("\nTempo de resolucao: %.1f segundos\n", tempo);

    return 0;
}
